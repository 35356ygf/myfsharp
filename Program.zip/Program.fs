﻿// Function to apply an exponent to a value
let applyExponent exponent value = pown value exponent

// Partially applying the function
let square = applyExponent 2
let cube = applyExponent 3

// Testing the partial application
let testSquare = square 5    // 5^2 = 25
let testCube = cube 2        // 2^3 = 8

printfn "Square of 5: %d" testSquare
printfn "Cube of 2: %d" testCube


//2
// Tail-recursive function to find the product of elements in a list
let rec productTailRecursive list acc =
    match list with
    | [] -> acc
    | head :: tail -> productTailRecursive tail (acc * head)

let product list = productTailRecursive list 1

// Testing the function
let testProduct = product [1; 2; 3; 4; 5]  // 1 * 2 * 3 * 4 * 5 = 120
printfn "Product of [1; 2; 3; 4; 5]: %d" testProduct



//3-  Tail-recursive function to find the product of all odd numbers from n to 1
let rec productOddNumbersTailRecursive n acc =
    if n < 1 then acc
    else productOddNumbersTailRecursive (n - 2) (acc * n)

let productOddNumbers n = productOddNumbersTailRecursive n 1

// Testing the function
let testProductOdd = productOddNumbers 11  // 11 * 9 * 7 * 5 * 3 * 1 = 10395
printfn "Product of odd numbers from 11 to 1: %d" testProductOdd



// 4.
let names : string list = [" Charles"; "Babbage  "; "  Von Neumann  "; "  Dennis Ritchie  "]

// Use map to trim spaces from each string in the list
let trimmedNames : string list = List.map (fun (name : string) -> name.Trim()) names

// Print the results
trimmedNames |> List.iter (printfn "%s")




//5.
// Step 1: Create a sequence of the first 700 positive integers
let numbers = Seq.init 700 (fun i -> i + 1)

// Step 2: Convert the sequence into a list
let numberList = Seq.toList numbers

// Step 3: Filter out those elements that are multiples of both 7 and 5
let filteredNumbers = List.filter (fun x -> x % 35 = 0) numberList

// Step 4: Sum all the filtered numbers using fold
let sumOfFilteredNumbers = List.fold (+) 0 filteredNumbers

// Print the result
printfn "Sum of filtered numbers: %d" sumOfFilteredNumbers



//6
// Define the list of strings
let names : string list = ["James"; "Robert"; "John"; "William"; "Michael"; "David"; "Richard"]

// Step 1: Filter elements that contain the letter 'I' (case-insensitive)
let filteredNames : string list = 
    List.filter (fun (name : string) -> 
        name.IndexOf("I", System.StringComparison.OrdinalIgnoreCase) >= 0
    ) names

// Print filtered names for debugging
printfn "Filtered names: %A" filteredNames

// Step 2: Concatenate all the filtered names using fold
let concatenatedNames : string = 
    List.fold (fun (acc : string) (name : string) -> acc + name) "" filteredNames

// Print the result
printfn "Concatenated names: %s" concatenatedNames




